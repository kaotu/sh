# Sharing is coming
#### This is a final project for  Hello World Alpaca workshop


## Menter
Front-end: Tulathorn Sripongpankul (P'TUL)\
Design: Jirapa Songchom (P'Jill)

## Contribuiter
### Design 
* N'Tae
### Front-end
* N'Jab
* N'First
* N'Nut
* N'Muta

## Technology
* React: create-react-app version xx.xx.xx
  https://github.com/facebookincubator/create-react-app
* CSS Framework: Boostap4 beta
  https://getbootstrap.com

## Oragized by Alchemist club 